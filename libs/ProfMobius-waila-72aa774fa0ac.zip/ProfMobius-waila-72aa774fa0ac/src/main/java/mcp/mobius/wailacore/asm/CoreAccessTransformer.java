package mcp.mobius.wailacore.asm;

import java.io.IOException;

import net.minecraftforge.fml.common.asm.transformers.AccessTransformer;

public class CoreAccessTransformer extends AccessTransformer {

    public CoreAccessTransformer() throws IOException {
        //super("waila_at.cfg");
    }
}
