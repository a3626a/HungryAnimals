package mcp.mobius.waila.gui.interfaces;

public enum WAlign {
LEFT,CENTER,RIGHT,TOP,BOTTOM;
}
