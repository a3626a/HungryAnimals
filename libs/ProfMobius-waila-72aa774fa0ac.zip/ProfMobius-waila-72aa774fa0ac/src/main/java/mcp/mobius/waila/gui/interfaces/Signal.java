package mcp.mobius.waila.gui.interfaces;

public enum Signal {
	DRAGGED,
	CLICKED,
	VALUE_CHANGED,
	GEOM_CHANGED;
}
