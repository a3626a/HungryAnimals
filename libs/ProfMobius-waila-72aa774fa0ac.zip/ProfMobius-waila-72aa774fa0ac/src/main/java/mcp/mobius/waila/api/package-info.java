@API(apiVersion="1.3",owner="Waila",provides="WailaAPI")
package mcp.mobius.waila.api;
import net.minecraftforge.fml.common.API;